package com.example.guiv3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Manage extends AppCompatActivity {

    private Button button1;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage);

        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStaffManagement();
            }
        });

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBookRoom();
            }
        });

    }
    public void openStaffManagement() {
        Intent intent1 = new Intent(this, StaffManagement.class);
        startActivity(intent1);
    }

    public void openBookRoom() {
        Intent intent2 = new Intent(this, BookRoom.class);
        startActivity(intent2);
    }
}
