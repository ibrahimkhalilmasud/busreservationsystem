package com.example.guiv3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class StaffManagement extends AppCompatActivity {

    private Button button1;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_management);

        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddStaff();
            }
        });

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCurrentStaffs();
            }
        });

    }
    public void openAddStaff() {
        Intent intent1 = new Intent(this, AddStaff.class);
        startActivity(intent1);
    }

    public void openCurrentStaffs() {
        Intent intent2 = new Intent(this, CurrentStaffs.class);
        startActivity(intent2);
    }
}
