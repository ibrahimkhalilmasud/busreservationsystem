package com.example.busreservationsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RoomMain extends AppCompatActivity {

    private Button RoomNo;
    private Button cancelBttn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_main);

        RoomNo= findViewById(R.id.Assignbttn);
        RoomNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), SupervisorLogin.class);
                startActivity(startIntent);
            }
        });

        cancelBttn = findViewById(R.id.CancelBttn);

        cancelBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), roomList.class);
                startActivity(startIntent);
            }
        });
    }
}
