package com.example.busreservationsystem;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class staffList extends AppCompatActivity {

    private Button registerStaff;
    private Button assignjobStaff;

    stafflistdata myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_list);

        ListView listView=(ListView)findViewById(R.id.staffListview);
        myDB=new stafflistdata(this);

        ArrayList<String> theList = new ArrayList<>();
        Cursor data =myDB.getlistContents();

        if (data.getCount() ==0){
            Toast.makeText(staffList.this,"Empty",
                    Toast.LENGTH_LONG).show();
        }else{
            while(data.moveToNext()){
                theList.add(data.getString(1));
                    ListAdapter listAdapter= new ArrayAdapter<>(this,
                            android.R.layout.simple_list_item_1,theList);
                    listView.setAdapter(listAdapter);
                }
            }

        

        registerStaff= findViewById(R.id.registerStaffBtn);
        registerStaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), StaffRegister.class);
                startActivity(startIntent);
            }
        });

        assignjobStaff= findViewById(R.id.assignJobStaff);
        assignjobStaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), roomList.class);
                startActivity(startIntent);
            }
        });

    }

}

