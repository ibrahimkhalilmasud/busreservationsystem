package com.example.busreservationsystem

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private var Login1: Button? = null
    private var Login2: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Login1 = findViewById(R.id.supervisorLoginButton)
        Login2 = findViewById(R.id.staffLoginButton)
        Login1!!.setOnClickListener {
            val startIntent = Intent(applicationContext, SupervisorLogin::class.java)
            startActivity(startIntent)
        }
        Login2!!.setOnClickListener {
            val startIntent = Intent(applicationContext, StaffLogin::class.java)
            startActivity(startIntent)
        }
    }
}