package com.example.GUIV2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button Login1;
    private Button Login2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Login1 = findViewById(R.id.supervisorLoginButton);
        Login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSupervisorLogin();
            }
        });

        Login2 = findViewById(R.id.staffLoginButton);
        Login2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStaffLogin2();
            }
        });

    }
    public void openSupervisorLogin() {
        Intent intent1 = new Intent(this, SupervisorLogin.class);
        startActivity(intent1);
    }

    public void openStaffLogin2() {
        Intent intent2 = new Intent(this, StaffLogin.class);
        startActivity(intent2);
    }
}
