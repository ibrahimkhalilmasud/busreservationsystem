package com.example.GUIV2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class roomList extends AppCompatActivity {

    private Button backBttn;
    private Button Enterroom1;
    private Button Enterroom2;
    private Button Enterroom3;
    private Button Enterroom4;
    private Button Enterroom5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_list);

        backBttn = findViewById(R.id.button6);

        backBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), SupervisorMain.class);
                startActivity(startIntent);
            }
        });

        Enterroom1 = findViewById(R.id.enter1);

        Enterroom1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RoomMain.class);
                startActivity(startIntent);
            }
        });

        Enterroom2 = findViewById(R.id.enter2);

        Enterroom2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RoomMain.class);
                startActivity(startIntent);
            }
        });

        Enterroom3 = findViewById(R.id.enter3);

        Enterroom3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RoomMain.class);
                startActivity(startIntent);
            }
        });

        Enterroom4 = findViewById(R.id.enter4);

        Enterroom4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RoomMain.class);
                startActivity(startIntent);
            }
        });

        Enterroom5 = findViewById(R.id.enter5);

        Enterroom5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RoomMain.class);
                startActivity(startIntent);
            }
        });
    }
}
